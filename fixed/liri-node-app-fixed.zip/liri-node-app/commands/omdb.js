const keys = require('../keys')
const omdb = require('omdb');
const request = require('request');
const omdbKeys = keys.ombdKeys;


const getMovie = (movieName) => {
    var urlHit = omdbKeys + movieName;

    request(urlHit, function(error, response, body) {
        console.log(response);
    });
};

module.exports = {
  getMovie
};
