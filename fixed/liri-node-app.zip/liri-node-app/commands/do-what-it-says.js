const fs = require('fs');

const commands = {
  movies: require('./omdb'),
  spotify: require('./spotify'),
  tweets: require('./twitter'),
}

function doWhatItSays() {
  fs.readFile('./commands/random.txt', (error, data) => {
		if (error) {
			throw error
		};

    let randomTxt = data.toString().split(',');
    		let command = randomTxt[0];
    		let randomCommand = randomTxt[1];

    		if (typeof commands[command] === 'function') {
    			commands[command](randomCommand);
    		}
    	});
    }
    module.exports = doWhatItSays;
